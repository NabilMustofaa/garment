<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Document</title>
</head>
<body>
    <h1> FORM</h1>
    <?php echo QrCode::size(100)->generate(Request::url()); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
        <script>
            alert('Please fill all the fields');
        </script>
    <?php endif; ?>
    <form action="/add/production" method="POST" id="createProduction" class="flex flex-col m-12">
        <?php echo csrf_field(); ?>
        <label for="name">Production Name</label>
        <input type="text" name="name" id="name" class="border border-gray-400 p-2">
        <label for="description">Production Description</label>
        <textarea name="description" id="description" cols="30" rows="10" class="border border-gray-400 p-2"></textarea>
        <label for="end_date">Production End Date</label>
        <input type="date" name="end_date" id="end_date" class="border border-gray-400 p-2">
        <label for="input_quantity">Input Quantity</label>
        <input type="number" name="input_quantity" id="input_quantity" class="border border-gray-400 p-2">
        <label for="material_id">Material Type</label>
        <select name="material_id" id="material_id" class="border border-gray-400 p-2">
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($material->id); ?>"><?php echo e($material->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="output_quantity">Projected Output</label>
        <input type="number" name="output_quantity" id="output_quantity" class="border border-gray-400 p-2">

        <button type="submit" class="bg-blue-500 text-white p-2">Submit</button>

    </form>
    <?php if(session('succes')): ?>
        <div class="bg-green-500 text-white p-2">
            <?php echo e(session('succes')); ?>

            
        </div>
        <script>
            console.log('succes');
        </script>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/form.blade.php ENDPATH**/ ?>