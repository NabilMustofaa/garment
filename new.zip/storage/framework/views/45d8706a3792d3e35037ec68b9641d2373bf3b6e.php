
<?php $__env->startSection('container'); ?>
    <center>
        <br>
        <hr class="navbar-divider">
        <label class="label">Edit Form Material</label>
        <hr class="navbar-divider">
        <br>
    </center>

    <form action="/material/<?php echo e($material->id); ?>" method="POST" id="createMaterial" class="flex flex-col m-12" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label class="label">Material Name</label>
            <div class="control">
                <input class="input" type="text" name="name" id="name" value="<?php echo e($material->material_name); ?>">
            </div>
        <label class="label">Material Description</label>
            <div class="control">
              <textarea class="textarea" name="description" id="description"><?php echo e($material->material_description); ?></textarea>
            </div>
        <label class="label">Material Measures</label>
        <select name="measure_unit" id="measure_unit" class="input">
                <option value="kg" <?php echo e($material->material_measure_unit == 'kg' ? 'selected' : ''); ?>>kg</option>
                <option value="l" <?php echo e($material->material_measure_unit == 'l' ? 'selected' : ''); ?>>l</option>
                <option value="m" <?php echo e($material->material_measure_unit == 'm' ? 'selected' : ''); ?>>m</option>
                <option value="piece" <?php echo e($material->material_measure_unit == 'piece' ? 'selected' : ''); ?>>piece</option>
            </select>

            <label class="label">Material Category</label>
            <div class="select" name="category" id="category">
                <select name="category" id="selectType" class=" border border-gray-400 p-2">
                    <option value="0" selected>Select to filter by Category...</option>
                    <?php $__currentLoopData = $materialCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($material->materialSubCategory->materialCategory->id == $category->id ? 'selected' : ''); ?>><?php echo e($category->category_name); ?></option>

                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                
                <select name="sub_category_id" id="selectSubType" class="border border-gray-400 p-2" >
                    <?php $__currentLoopData = $material->materialSubCategory->materialCategory->materialSubCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subCategory->id); ?>" <?php echo e($material->material_sub_category_id == $subCategory->id ? 'selected' : ''); ?>><?php echo e($subCategory->sub_category_name); ?></option>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
    
            </div>
            <label class="label mt-2">Material Image</label>
            <div class="flex">
                <input class="block w-full text-sm text-gray-900 border rounded-lg p-2" id="file_input" name="material_image" type="file">
                <img src="<?php echo e(asset('uploads/material/'.$material->material_image)); ?>" alt="" id="image" class=" w-24 h-24 hidden object-cover">
            </div>


        <br>
        <button type="submit" class="button green">Submit</button>

    </form>

    <script src="<?php echo e(asset("js/formMaterial.js")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\PROJECT\garment\resources\views/material/editMaterial.blade.php ENDPATH**/ ?>