

<?php $__env->startSection('content'); ?>

<h1>Edit Form Process</h1>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
    </div>
    <script>
        alert('Please fill all the fields');
    </script>
<?php endif; ?>

<form action="/change/<?php echo e($process->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-4">
        <label for="process_output_quantity" >Output Quantity</label>
        <input type="number" name="process_output_quantity" id="process_output_quantity" placeholder="Output Quantity" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e($process->process_output_quantity); ?>">
    </div>
    <div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium w-full">Update</button>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/process/updateProcess.blade.php ENDPATH**/ ?>