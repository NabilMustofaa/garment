<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('css/main.css?v=1628755089081')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('https://cdn.materialdesignicons.com/4.9.95/css/materialdesignicons.min.css')); ?>">

</head>
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div style="padding: 1rem">
      <?php echo $__env->yieldContent('container'); ?>
    </div>
</body>
<script src="<?php echo e(url('https://cdn.tailwindcss.com')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/main.min.js?v=1628755089081')); ?>"></script>
</html><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/layouts/main.blade.php ENDPATH**/ ?>