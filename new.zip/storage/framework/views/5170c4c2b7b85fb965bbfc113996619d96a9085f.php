

<?php $__env->startSection('container'); ?>

<center>
    <hr class="navbar-divider">
    <label class="label">Table Process</label>
    <hr class="navbar-divider">
    <br>
</center>

<div class="">
    
    <!--<a href="/processtype/create" class="bg-blue-500 text-white px-4 py-3 rounded font-medium" style="padding: 0.5rem">Tambah Proses</a>-->
</div>
<?php if(session('succes')): ?>
    <div class="bg-green-500 text-black p-2">
        <?php echo e(session('succes')); ?>

    </div>
    <script>
        alert('succes');
    </script>
<?php endif; ?>
<div class="overflow-x-auto relative shadow-md sm:rounded-lg">
    <table class="w-full text-sm text-gray-200 dark:text-gray-800" id="materialTable">
        <thead class="border-b bg-gray-300">
        <tr>
            <th class="border px-4 py-2 text-center">Name</th>
            <th class="border px-4 py-2 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $processTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($process->process_type_name); ?></td>
                <td class="border px-4 py-2 text-center">
                    <a href="/processtype/<?php echo e($process->id); ?>/edit" class="bg-blue-500 text-white p-2 rounded">Edit</a>
                    <!--<form action="/processtype/<?php echo e($process->id); ?>" method="POST" class="inline">-->
                    <!--    <?php echo csrf_field(); ?>-->
                    <!--    <?php echo method_field('DELETE'); ?>-->
                    <!--    <button type="submit" class="bg-red-500 text-white p-2">Delete</button>-->
                    <!--</form>-->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="font-bold">
    Nb: Jalannya proses urut dari atas ke bawah
    
</div>
</div>

<center>
    <br>
    <hr class="navbar-divider">
    <label class="label">Table Production Types</label>
    <hr class="navbar-divider">
    <br>
</center>
<div class="mb-5">
    <a href="/productiontype/create" class="bg-blue-500 text-white px-4 py-3 rounded font-medium" style="padding: 0.5rem">Create</a>
</div>

<?php if(session('succes')): ?>
    <div class="bg-green-500 text-black p-2">
        <?php echo e(session('succes')); ?>

    </div>
    <script>
        alert('succes');
    </script>
<?php endif; ?>

<div class="overflow-x-auto relative shadow-md sm:rounded-lg">
    <table class="w-full text-sm text-gray-200 dark:text-gray-800" id="materialTable">
        <thead class="border-b bg-gray-300">
        <tr>
            <th class="border px-4 py-2 text-center">Name</th>
            <th class="border px-4 py-2 text-center">Description</th>
            <th class="border px-4 py-2 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productionProcessTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($production[0]->production_type->production_type_name); ?></td>
                <td class="border px-4 py-2">
                    <?php $__currentLoopData = $production; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ps->process_type_id == 1 || $ps->process_type_id ==5): ?>
                            <?php continue; ?>
                        <?php else: ?>
                        <?php echo e($ps->process_type->process_type_name); ?> <br>
                        <?php endif; ?>

                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                
                <td class="border px-4 py-2 text-center">
                    <a href="/productiontype/<?php echo e($production[0]->production_type->id); ?>/edit" class="bg-blue-500 text-white p-2 rounded">Edit</a>
                    <!--<form action="/productiontype/<?php echo e($production[0]->production_type->id); ?>" method="POST" class="inline">-->
                    <!--    <?php echo csrf_field(); ?>-->
                    <!--    <?php echo method_field('DELETE'); ?>-->
                    <!--    <button type="submit" class="bg-red-500 text-white p-2">Delete</button>-->
                    <!--</form>-->
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>

<center>
    <br>
    <hr class="navbar-divider">
    <label class="label">Table Person Process</label>
    <hr class="navbar-divider">
    <br>
</center>
<div class="mb-5">
    <a href="/user/create" class="bg-blue-500 text-white px-4 py-3 rounded font-medium" style="padding: 0.5rem">Create</a>
</div>

<?php if(session('succes')): ?>
    <div class="bg-green-500 text-black p-2">
        <?php echo e(session('succes')); ?>

    </div>
    <script>
        alert('succes');
    </script>
<?php endif; ?>

<div class="overflow-x-auto relative shadow-md sm:rounded-lg">
    <table class="w-full text-sm text-gray-200 dark:text-gray-800" id="materialTable">
        <thead class="border-b bg-gray-300">
        <tr>
            <th class="border px-4 py-2 text-center">Name</th>
            <th class="border px-4 py-2 text-center">Description</th>
            <th class="border px-4 py-2 text-center">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $personProcesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="border px-4 py-2"><?php echo e($person[0]->user->name); ?></td>
                <td class="border px-4 py-2">
                    <?php $__currentLoopData = $person; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($ps->process_type_id == 7): ?>
                    <?php continue; ?>
                    <?php else: ?>
                    <?php echo e($ps->process_type->process_type_name); ?> <br>
                    <?php endif; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                
                <td class="border px-4 py-2 text-center">
                    <a href="/user/<?php echo e($person[0]->user->id); ?>/edit" class="bg-blue-500 text-white p-2 rounded">Edit</a>
                    <!--<form action="/user/<?php echo e($person[0]->user->id); ?>" method="POST" class="inline">-->
                    <!--    <?php echo csrf_field(); ?>-->
                    <!--    <?php echo method_field('DELETE'); ?>-->
                    <!--    <button type="submit" class="bg-red-500 text-white p-2">Delete</button>-->
                    <!--</form>-->
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\PROJECT\garment\resources\views/process/indexProcess.blade.php ENDPATH**/ ?>