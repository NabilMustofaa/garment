

<?php $__env->startSection('container'); ?>

    <center>
        <br>
        <hr class="navbar-divider">
        <label class="label">Edit Form Produksi</label>
        <hr class="navbar-divider">
        <br>
    </center>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
    </div>
    <script>
        alert('Please fill all the fields');
    </script>
<?php endif; ?>

<form action="/production/<?php echo e($production->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-4">
        <label for="production_name" >Name</label>
        <input type="text" name="production_name" id="production_name" placeholder="Name" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e($production->production_name); ?>">
    </div>
    <div class="mb-4">
        <label for="production_description" >Description</label>
        <input type="text" name="production_description" id="production_description" placeholder="Description" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e($production->production_description); ?>">
    </div>
    
    <div class="mb-4">
    <label for="production_type" >Type</label>
    <select name="production_type" id="production_type" class="bg-gray-100 border-2 w-full p-4 rounded-lg">
        <?php echo e($production->production_type); ?>

        <?php $__currentLoopData = $productionType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($type->id == $production->production_type): ?>
                <option value="<?php echo e($type->id); ?>" selected><?php echo e($type->production_type_name); ?></option>
            <?php else: ?>
                <option value="<?php echo e($type->id); ?>"><?php echo e($type->production_type_name); ?></option>    
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>

    <div class="mb-4">
        <label for="production_projected_end_date" >Projected End Date</label>
        <input type="date" name="production_projected_end_date" id="production_projected_end_date" placeholder="Projected End Date" class="bg-gray-100 border-2 w-full p-4 rounded-lg" value="<?php echo e($production->production_projected_end_date); ?>">
    </div>
    <div>
        <button type="submit" class="bg-blue-500 text-white px-4 py-3 rounded font-medium w-full">Update</button>
    </div>  
</form>



    


<?php if(session('succes')): ?>
    <div class="bg-green-500 text-white p-2">
        <?php echo e(session('succes')); ?>

        
    </div>
    <script>
        console.log('succes');
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\PROJECT\garment\resources\views/production/editProduction.blade.php ENDPATH**/ ?>