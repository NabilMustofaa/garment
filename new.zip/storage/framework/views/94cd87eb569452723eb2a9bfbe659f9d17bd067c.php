
<?php $__env->startSection('container'); ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
        <script>
            alert('Please fill all the fields');
        </script>
    <?php endif; ?>
    <form action="/production" method="POST" id="createProduction" class="flex flex-col m-12">
        <?php echo csrf_field(); ?>
    <center>
        <hr class="navbar-divider">
        <label class="label">Form Produksi</label>
        <hr class="navbar-divider">
        <br>
    </center>
        <label class="label text-md">Production Name</label>
        <input required class="input" type="text" name="name" id="name" placeholder="Production Name">
        <label class="label text-md">Production Type</label>
        <select name="production_type" id="production_type" class="border border-gray-400 p-2 rounded">
            <?php $__currentLoopData = $productionType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($type->id); ?>"><?php echo e($type->production_type_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label class="label text-md">Production Description</label>
        <textarea required class="textarea" name="description" id="description" placeholder="Production Description"></textarea>
        <label for="end_date" class="label text-md">Production End Date</label>
        <input required type="date" name="end_date" id="end_date" class="border border-gray-400 p-2 rounded" value="<?php echo e(date('Y-m-d')); ?>">
    <center>
        <br>
        <hr class="navbar-divider">
            <label class="label">Material</label>
        <hr class="navbar-divider">
        <br>
    </center>
        <div class="materialContainer mb-0">
            <div class="flex h-20">
                <div class="flex flex-col w-3/4">
                    <label for="material_id" class="label">Material Type</label>
                    <div class=" w-full flex flex-row">
                        <select name="category" id="selectType_1" class=" border border-gray-400 p-3 m-0 w-1/3 rounded" onchange="changeSubtype(1)">
                            <option value="0" selected>Select Category</option>
                            <?php $__currentLoopData = $materialCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                
                        <select name="type" id="selectSubType_1" class="border border-gray-400 p-3 m-0 w-1/3 rounded" disabled>
                            <option value="0">Select Sub Category</option>
                        </select>
                        <select name="material_id_1" id="material_id_1" class="border border-gray-400 rounded-sm p-3 h-12 w-1/3 rounded" disabled>
                            <option value="0" selected>Select Sub Category first</option>
                        </select>
                    </div>
                </div>
                <div class="flex flex-col w-1/4">
                    <label for="input_quantity" class="label">Quantity Material</label>
                    <input required type="number" name="input_quantity_1" id="input_quantity_1" class="border border-gray-400 rounded-sm p-3 h-12 rounded" min="0" >
                </div>
                    <img src="<?php echo e(Asset('uploads/material/default.jpg')); ?>" alt="" class="w-12 h-12 mt-8 object-cover" id="material_image_1">
            </div>
        </div>
        <br>
        <button id="materialButton" type="button" class="bg-blue-500 w-full m-0 p-2 text-white rounded">Add</button>
        <input required type="hidden" name="totalMaterial" id="totalMaterial" value="1">
        
        <center>
            <br>
            <hr class="navbar-divider">
            <label for="output_quantity" class="label">Projected Output</label>
            <hr class="navbar-divider">
        </center>
        <label for="output_quantity" class="label ">Pilih Warna</label>
        
        <div class="flex ">
            <div class="flex flex-col w-full">
                <div class="flex">
                    <input required type="text" name="search" id="colorSearch" class="border border-gray-400 p-2 w-11/12 rounded" placeholder="Search Color">
                    <button type="button" class="bg-blue-500 w-1/12 m-0 p-2 text-white rounded-sm disabled:bg-blue-300" id="colorAdd" disabled> Add</button>
                </div>
                <div class="bg-white w-11/12 shadow-lg p-2 hidden " id="colorList">
                    
                </div>

            </div>
        </div>

        

        <div id="placeholderInput">
        </div>
       <br>
        <button type="submit" class="button green">Submit</button>

    </form>
    <?php if(session('succes')): ?>
        <div class="bg-green-500 text-white p-2">
            <?php echo e(session('succes')); ?>

            
        </div>
        <script>
            console.log('succes');
        </script>
    <?php endif; ?>

    <script src="<?php echo e(asset('js/production.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/production/formProduction.blade.php ENDPATH**/ ?>