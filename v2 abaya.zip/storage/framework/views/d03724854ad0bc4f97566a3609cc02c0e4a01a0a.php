<nav id="navbar-main" class="navbar is-fixed-top" style="justify-content: flex-end">
      <div class="navbar-item dropdown has-divider has-user-avatar">
        <a class="navbar-link">
          <div class="user-avatar">
            <img src="https://avatars.dicebear.com/v2/initials/john-doe.svg" alt="John Doe" class="rounded-full">
          </div>
          <div class="is-user-name"><span><?php echo e(Auth::user()->name); ?></span></div>
          <span class="icon"><i class="mdi mdi-chevron-down"></i></span>
        </a>
        <div class="navbar-dropdown">
          
          <form action="/logout" method="get">
            <?php echo csrf_field(); ?>
            <button type="submit" class="mdi mdi-logout" style="padding: 1.1rem">
                Logout
                <span data-feather="log-out"></span>
            </button>
          </form>
        </div>
      </div>
</nav><?php /**PATH C:\Users\User\Documents\Program\PROJECT\garment\resources\views/layouts/header.blade.php ENDPATH**/ ?>