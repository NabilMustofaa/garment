
<?php $__env->startSection('container'); ?>

<select name="process_material_id" id="selectMaterial">
  <?php $__currentLoopData = $processMats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($pm->id); ?>"><?php echo e($pm->process_material_name); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
<?php $__currentLoopData = $processMats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <input type="hidden" id="<?php echo e($pm->id); ?>" value="<?php echo e($pm->process_material_quantity); ?>" hidden>
  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<input type="number" name="quantity" id="" min="0" max="<?php echo e($processMats[0]->process_material_quantity); ?>" value="<?php echo e($processMats[0]->process_material_quantity); ?>">
<script>
  const selectMaterial = document.querySelector('#selectMaterial');
  const quantity = document.querySelector('input[name="quantity"]');
  const actualQuantity = document.querySelector('input[id="' + selectMaterial.value + '"]]');

  selectMaterial.addEventListener('change', function() {
    quantity.setAttribute('max', actualQuantity.value);
    quantity.value = actualQuantity.value;
  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/production/sendProduction.blade.php ENDPATH**/ ?>