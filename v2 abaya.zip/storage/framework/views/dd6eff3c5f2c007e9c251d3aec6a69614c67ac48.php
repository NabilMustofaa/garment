
<?php $__env->startSection('container'); ?>

<div class="container shadow-md">
    <div class="row justify-content-center">
        <div class="col-8">
            <div class="card sm:rounded-lg" style="padding: 2rem">
                <div class="card-body">
                    <label class="label">Edit Form Material</label>
                    <form action="/material/<?php echo e($material->id); ?>" method="POST" id="createMaterial" class="flex flex-col m-12" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label class="label">Material Name</label>
                            <div class="control">
                                <input class="input" type="text" name="name" id="name" value="<?php echo e($material->material_name); ?>">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="label">Material Description</label>
                            <div class="control">
                                <textarea class="textarea" name="description" id="description"><?php echo e($material->material_description); ?></textarea>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="label">Material Measures</label>
                            <select name="measure_unit" id="measure_unit" class="input">
                                <option value="kg" <?php echo e($material->material_measure_unit == 'kg' ? 'selected' : ''); ?>>kg</option>
                                <option value="l" <?php echo e($material->material_measure_unit == 'l' ? 'selected' : ''); ?>>l</option>
                                <option value="m" <?php echo e($material->material_measure_unit == 'm' ? 'selected' : ''); ?>>m</option>
                                <option value="piece" <?php echo e($material->material_measure_unit == 'piece' ? 'selected' : ''); ?>>piece</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="label">Material Category</label>
                            <div class="select" name="category" id="category">
                                <select name="category" id="selectType" class=" border border-gray-400 p-2 mb-3">
                                    <option value="0" selected>Select to filter by Category...</option>
                                    <?php $__currentLoopData = $materialCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e($material->materialSubCategory->materialCategory->id == $category->id ? 'selected' : ''); ?>><?php echo e($category->category_name); ?></option> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <select name="sub_category_id" id="selectSubType" class="border border-gray-400 p-2" >
                                    <?php $__currentLoopData = $material->materialSubCategory->materialCategory->materialSubCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($subCategory->id); ?>" <?php echo e($material->material_sub_category_id == $subCategory->id ? 'selected' : ''); ?>><?php echo e($subCategory->sub_category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <div class="mb-3">
                            <label class="label mt-2">Material Image</label>
                            <div class="flex">
                                <input class="block w-full text-sm text-gray-900 border rounded-lg p-2" id="file_input" name="material_image" type="file">
                                <img src="<?php echo e(asset('uploads/material/'.$material->material_image)); ?>" alt="" id="image" class=" w-24 h-24 hidden object-cover">
                            </div>
                                <br>
                                <div class="bg-gray-50 px-4 py-3 text-right sm:px-1">
                            <button type="submit" class="flex-end justify-center rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-5">Submit</button>
                        </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

    <script src="<?php echo e(asset("js/formMaterial.js")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/material/editMaterial.blade.php ENDPATH**/ ?>