<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
  <link rel="stylesheet" href="<?php echo e(url('css/main.css?v=1628755089081')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('https://cdn.materialdesignicons.com/4.9.95/css/materialdesignicons.min.css')); ?>">

</head>
<body class=" p-4">
    <div class=" p-0">
        <h1 class=" text-xl font-bold my-4"> Laporan Hasil Kerja</h1>
        <table>
            <tr>
                <td class=" border border-black bg-gray-200">Nama Proses</td>
                <td class=" border border-black">
                    <h2>Proses <?php echo e($subProses->subProcess->process->process_name); ?></h2>
                </td>
            </tr>
            <tr>
                <td class=" border border-black bg-gray-200">Nama Penyelesai</td>
                <td class=" border border-black"><h1><?php echo e($subProses->subProcess->user->name); ?></h1></td>
                
            </tr>
            <tr>
                <td class=" border border-black bg-gray-200">Nama Material</td>
                <td class=" border border-black"><?php echo e($subProses->subProcess->processMaterial->process_material_name); ?></td>
            </tr>
            <tr>
                <td class=" border border-black bg-gray-200">Jumlah Target</td>
                <td class=" border border-black"><?php echo e($subProses->subProcess->sub_proses_projected); ?></td>
            </tr>

            <tr>
                <td class=" border border-black bg-gray-200">Jumlah yang sudah di proses</td>
                <td class=" border border-black"><?php echo e($subProses->subProcess->sub_proses_actual); ?></td>
            </tr>
            <tr>
                <td class=" border border-black bg-gray-200">Jumlah yang diserahkan</td>
                <td class=" border border-black"><?php echo e($subProses->quantity); ?></td>
            </tr>
            <tr>
                <td class=" border border-black bg-gray-200">Tanggal Diselesaikan</td>
                <td class=" border border-black"><?php echo e($subProses->subProcess->updated_at); ?></td>
            </tr>
        </table>
        <br>
        <?php if($subProses->is_done == 1): ?>
            <h1>Sub Process Selesai dan telah dikonfirmasi</h1>

        <?php else: ?>
        <div class="flex">
        <form action="/report/<?php echo e($subProses->id); ?>" method="POST" class="flex">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="quantity" value="<?php echo e($subProses->quantity); ?>">
            <input type="hidden" name="sph_id" value="<?php echo e($subProses->id); ?>">
            <input type="hidden" name="user_id" value="<?php echo e($subProses->subProcess->user_id); ?>">
            <input type="hidden" name="process_id" value="<?php echo e($subProses->subProcess->process_id); ?>">
            <input type="hidden" name="process_material_id" value="<?php echo e($subProses->subProcess->process_material_id); ?>">
            <input type="number" name="quantity_rusak" class="input h-12" max="<?php echo e($subProses->quantity); ?>" required min=0>
            <button type="submit" class="bg-red-500 text-white px-4 py-3 rounded font-medium">Laporkan</button>
        
        </form>
        </div>
        <?php endif; ?>
        
        
    </div>
</body>
<script src="<?php echo e(url('https://cdn.tailwindcss.com')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/main.min.js?v=1628755089081')); ?>"></script>
</html>

<?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/subproses/report.blade.php ENDPATH**/ ?>