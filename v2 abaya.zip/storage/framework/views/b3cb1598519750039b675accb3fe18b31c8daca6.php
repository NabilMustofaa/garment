
<?php $__env->startSection('container'); ?>

<div class="container shadow-md">
    <div class="row justify-content-center">
        <div class="col-8">
            <div class="card sm:rounded-lg" style="padding: 2rem">
                <div class="card-body">
                    <label class="label text-center mb-4">Form Tipe Produksi</label>
                    <Form method="POST" action="/productiontype/<?php echo e($productionType->id); ?>" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-4">
                            <label for="name" class="sr-only">Name</label>
                            <input type="text" name="name" id="name" placeholder="Production Name" class="bg-gray-100 border-2 w-full p-4 rounded-lg mt-4 mb-4 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($productionType->production_type_name); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-red-500 mt-2 text-sm">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                            <div class="mb-4">
                                <label for="role" class="sr-only">Role</label>
                                <div class="flex flex-col mt-4">
                                    <?php $__currentLoopData = $processTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $process): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(in_array($process->id, $productionType->production_process->pluck('process_type_id')->toArray())): ?>
                                            <label for="process"><?php echo e($process->process_type_name); ?></label>
                                            <input type="checkbox" name="process[]" value="<?php echo e($process->id); ?>" class="bg-gray-100 border-2 w-full rounded-lg" checked>
                                        <?php else: ?>
                                            <label for="process"><?php echo e($process->process_type_name); ?></label>
                                            <input type="checkbox" name="process[]" value="<?php echo e($process->id); ?>" class="bg-gray-100 border-2 w-full rounded-lg">
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="bg-gray-50 px-4 py-3 text-right sm:px-1">
                                <button type="submit" class="flex justify-start rounded-md border border-transparent bg-indigo-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-5">Register</button>
                            </div>
                    </Form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/productionType/edit.blade.php ENDPATH**/ ?>