<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="https://cdn.tailwindcss.com"></script>
    <title>Document</title>
</head>
<body>
    <h1>
        FORM Material
    </h1>

    <?php if($errors->any()): ?>

        <script>
            alert($errors);
        </script>

    <?php endif; ?>
    
    <form action="/material" method="POST" id="createMaterial" class="flex flex-col m-12">
        <?php echo csrf_field(); ?>
        <label for="name">Material Name</label>
        <input type="text" name="name" id="name" class="border border-gray-400 p-2">
        <label for="description">Material Description</label>
        <textarea name="description" id="description" cols="30" rows="10" class="border border-gray-400 p-2"></textarea>
        <label for="quantity">Material Quantity</label>
        <div>
            <input type="number" name="quantity" id="quantity" class="border border-gray-400 p-2">
            <select name="measure_unit" id="measure_unit" class=" ">
                <option value="kg">kg</option>
                <option value="l">l</option>
                <option value="m">m</option>
                <option value="piece">piece</option>
            </select>
        </div>
        <label for="type">Material type</label>
        <select name="type" id="type" class="border border-gray-400 p-2">
            <option value="raw">Raw</option>
            <option value="semi-finished">Semi-finished</option>
            <option value="finished">Finished</option>
        </select>
        <button type="submit" class="bg-blue-500 text-white p-2">Submit</button>
    </form>
    <?php if(session('succes')): ?>
        <div class="bg-green-500 text-black p-2">
            <?php echo e(session('succes')); ?>

            {}
            
        </div>
        <script>
            alert('succes');
        </script>
    <?php endif; ?>
    
</body>
</html><?php /**PATH C:\Users\User\Documents\Program\laravel\garment\resources\views/formMaterial.blade.php ENDPATH**/ ?>