<aside class="aside is-placed-left is-expanded">
  <div class="aside-tools">
    <div>
      Abaya <b class="font-black">Salma</b>
    </div>
  </div>
  <div class="menu is-menu-main">
    
    
    <p class="menu-label">Proses Bisnis</p>
    <ul class="menu-list">
      <li class="--set-active-tables-html">
        <a href="/material">
          <span class="icon"><i class="mdi mdi-table"></i></span>
          <span class="menu-item-label"  >Material</span>
        </a>
      </li>
      <li class="--set-active-forms-html">
        <a href="/production">
          <span class="icon"><i class="mdi mdi-square-edit-outline"></i></span>
          <span class="menu-item-label" >Produksi</span>
        </a>
      </li>
      <li class="--set-active-profile-html">
        <a href="/process">
          <span class="icon"><i class="mdi mdi-clipboard-check"></i></span>
          <span class="menu-item-label">Proses</span>
        </a>
      </li>
    </ul>
  </div>
</aside><?php /**PATH /home/nabilmus/abaya.nabilmustofa.my.id/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>